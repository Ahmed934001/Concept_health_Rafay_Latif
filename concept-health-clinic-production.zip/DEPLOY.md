# Concept Health Clinic — Deployment Guide

**Build:** production, November 2026
**Contents:** 3 HTML pages, 2 stylesheets, 5 scripts, 13 image assets
**Size:** ~1.4 MB (mostly the portrait JPEGs)

---

## 1. What's in this folder

```
index.html              Homepage — the whole site experience
privacy-policy.html     Privacy policy (indexable)
accessibility.html      Accessibility statement (indexable)
robots.txt              Crawl rules + sitemap pointer
sitemap.xml             3 live URLs, valid XML

css/style.css           Design system, components, motion, responsive rules
css/legal.css           Document-page layout

js/config.js            Single source of truth: clinic NAP, hours, chatbot graph
js/main.js              Nav, reveals, tilt, counters, FAQ, hours, map, form
js/analytics.js         Privacy-first visitor + call counters
js/engagement.js        Countdown, social proof toasts
js/chatbot.js           "Clara" conversation engine

assets/                 Logo set, favicon, OG card, 4 portrait crops (+ 2x variants)

.htaccess               Apache/LiteSpeed config (clean URLs, HTTPS, headers, caching)
_headers                Same rules for Netlify / Cloudflare Pages
_redirects              Extensionless URL mapping for Netlify / Cloudflare Pages
```

---

## 2. Upload

Pick **one** server type — the config files are alternatives, not cumulative.

### Apache / LiteSpeed / cPanel
Upload everything including `.htaccess` to the web root (`public_html/`).
The `.htaccess` handles HTTPS redirect, www redirect, extensionless URLs,
compression, caching and security headers.

### Netlify / Cloudflare Pages / Vercel
Drag the whole folder in, or connect the repo. `.htaccess` is ignored harmlessly;
`_headers` and `_redirects` do the work.

### Plain static host (no config support)
Everything works, but `/privacy-policy` will 404 — visitors must use
`/privacy-policy.html`. Either accept that, or edit the three canonicals and the
two sitemap entries to include `.html`.

---

## 3. Before you go live — 3 required settings

These are the only things that genuinely block launch:

### a) Unique analytics namespace
`js/config.js`, line 59:

```js
namespace: "chc-denison-tx",
```
Change to something unique to this clinic. **Warning:** the current namespace is
shared, so the counters on this site include traffic from any other build using
it. Use short names (Abacus rejects long ones), lowercase, hyphens allowed.

### b) Google Ads conversion ID (optional — only if you run Ads)
`js/config.js`, around line 76:

```js
conversionId: "",
```
Set to your `AW-XXXXXXXXX` or `G-XXXXXXXXXX`. Left blank, call clicks are still
tracked in the dataLayer and the on-site counter, just no Ads conversion fires.

### c) Form endpoint (optional — recommended)
`index.html`, just after `js/config.js`:

```html
<script>window.CHC.forms = { endpoint: "https://your-secure-handler" };</script>
```

**Until this is set, the inquiry form does not pretend to work.** On submit it
says plainly that it isn't connected yet and hands the visitor the phone number
and a pre-filled email. That is deliberate — the content brief requires never
claiming a submission succeeded without server confirmation, and a healthcare
form must not silently drop messages.

---

## 4. After upload — verify these five things

1. `https://yourdomain.com/` loads and the hero portrait is correctly framed.
2. `https://yourdomain.com/privacy-policy` (no `.html`) resolves, or you've
   accepted the `.html` URL.
3. `https://yourdomain.com/sitemap.xml` returns XML, not a 404.
4. The phone number is tappable on a real phone and dials (903) 600-2100.
5. Submit the sitemap in Google Search Console and Bing Webmaster Tools.

---

## 5. Known placeholders to replace when available

| Item | Where | Note |
|---|---|---|
| Generic social profiles | Footer + schema | Removed. The footer now links Google Maps, phone, email and portal. Add real Facebook/Instagram/LinkedIn URLs when they exist, then restore `sameAs` in the JSON-LD. |
| Stock environmental photos | Specialties & About sections | Licensed stock. Swap for approved clinic photography. Alt text is already written to describe intended content. |
| Google Maps embed | Contact + footer maps | Uses the query-based embed. Swap in the official place-ID embed once the Google Business Profile is verified, so the pin lands on Suite 203, not the plaza. |
| `dr-rafay-square.jpg` | `assets/` | Currently unused (the gallery was removed). Kept in case a portrait tile is needed later. Safe to delete. |

---

## 6. Architecture notes worth knowing

- **No build step.** No bundler, no npm install, no framework. Upload and it runs.
- **Progressive enhancement.** Every module is wrapped in an isolated initialiser;
  if GSAP or a CDN fails, content still renders and every link still works.
- **Counters degrade honestly.** If the Abacus API is unreachable (blocker,
  offline, corporate proxy), the site shows a clearly-labelled local tally rather
  than fake numbers or a broken dash.
- **Portraits are pre-composed.** Every crop places the eye-line at a fixed
  percentage from the top with the head at a fixed share of the frame. Containers
  must keep `object-position: 50% 50%` and their `aspect-ratio` must match the
  file, or the framing will drift.
- **Chatbot copy is fixed.** The closing line is verbatim as specified:
  "This conversation has been ended. Please contact our customer support for more
  details", followed by a call button.
